// D2Q9 shifted populations g=f-w. Orthogonal raw-moment MRT, Guo force.
struct Params { nx:u32, ny:u32, periodic_y:u32, omega:f32, force:vec2<f32>, scale:f32, pad:f32 }
@group(0) @binding(0) var<uniform> p:Params;
@group(0) @binding(1) var<storage,read_write> src:array<f32>;
@group(0) @binding(2) var<storage,read_write> dst:array<f32>;
@group(0) @binding(3) var<storage,read_write> output:array<vec4<f32>>;
@group(0) @binding(4) var<storage,read> mask:array<u32>;
const C=array<vec2<i32>,9>(vec2(0,0),vec2(1,0),vec2(0,1),vec2(-1,0),vec2(0,-1),vec2(1,1),vec2(-1,1),vec2(-1,-1),vec2(1,-1));
const W=array<f32,9>(4./9.,1./9.,1./9.,1./9.,1./9.,1./36.,1./36.,1./36.,1./36.);
const OPP=array<u32,9>(0,3,4,1,2,7,8,5,6);
@compute @workgroup_size(128)
fn collide_stream(@builtin(global_invocation_id) id:vec3<u32>) {
 let i=id.x;let n=p.nx*p.ny;if(i>=n){return;}
 if(mask[i]!=0u){return;}
 var f:array<f32,9>;var drho=0.;var j=vec2(0.);
 for(var q=0u;q<9u;q++){f[q]=src[q*n+i];drho+=f[q];j+=vec2<f32>(C[q])*f[q];}
 let rho=1.+drho;let u=(j+0.5*p.force)/rho;
 var d:array<f32,9>;var z:array<f32,9>;
 for(var q=0u;q<9u;q++){
  let cv=vec2<f32>(C[q]);let cu=dot(cv,u);
  let eq=W[q]*(drho+rho*(3.*cu+4.5*cu*cu-1.5*dot(u,u)));
  d[q]=f[q]-eq;z[q]=W[q]*dot(3.*(cv-u)+9.*cu*cv,p.force);
 }
 var dm:array<f32,9>;
 dm[0]=-(0.)*((1.0*d[0]) + (1.0*d[1]) + (1.0*d[2]) + (1.0*d[3]) + (1.0*d[4]) + (1.0*d[5]) + (1.0*d[6]) + (1.0*d[7]) + (1.0*d[8]))+(1.-0.5*(0.))*((1.0*z[0]) + (1.0*z[1]) + (1.0*z[2]) + (1.0*z[3]) + (1.0*z[4]) + (1.0*z[5]) + (1.0*z[6]) + (1.0*z[7]) + (1.0*z[8]));
 dm[1]=-(1.1)*((-4.0*d[0]) + (-1.0*d[1]) + (-1.0*d[2]) + (-1.0*d[3]) + (-1.0*d[4]) + (2.0*d[5]) + (2.0*d[6]) + (2.0*d[7]) + (2.0*d[8]))+(1.-0.5*(1.1))*((-4.0*z[0]) + (-1.0*z[1]) + (-1.0*z[2]) + (-1.0*z[3]) + (-1.0*z[4]) + (2.0*z[5]) + (2.0*z[6]) + (2.0*z[7]) + (2.0*z[8]));
 dm[2]=-(1.)*((4.0*d[0]) + (-2.0*d[1]) + (-2.0*d[2]) + (-2.0*d[3]) + (-2.0*d[4]) + (1.0*d[5]) + (1.0*d[6]) + (1.0*d[7]) + (1.0*d[8]))+(1.-0.5*(1.))*((4.0*z[0]) + (-2.0*z[1]) + (-2.0*z[2]) + (-2.0*z[3]) + (-2.0*z[4]) + (1.0*z[5]) + (1.0*z[6]) + (1.0*z[7]) + (1.0*z[8]));
 dm[3]=-(0.)*((1.0*d[1]) + (-1.0*d[3]) + (1.0*d[5]) + (-1.0*d[6]) + (-1.0*d[7]) + (1.0*d[8]))+(1.-0.5*(0.))*((1.0*z[1]) + (-1.0*z[3]) + (1.0*z[5]) + (-1.0*z[6]) + (-1.0*z[7]) + (1.0*z[8]));
 dm[4]=-(1.2)*((-2.0*d[1]) + (2.0*d[3]) + (1.0*d[5]) + (-1.0*d[6]) + (-1.0*d[7]) + (1.0*d[8]))+(1.-0.5*(1.2))*((-2.0*z[1]) + (2.0*z[3]) + (1.0*z[5]) + (-1.0*z[6]) + (-1.0*z[7]) + (1.0*z[8]));
 dm[5]=-(0.)*((1.0*d[2]) + (-1.0*d[4]) + (1.0*d[5]) + (1.0*d[6]) + (-1.0*d[7]) + (-1.0*d[8]))+(1.-0.5*(0.))*((1.0*z[2]) + (-1.0*z[4]) + (1.0*z[5]) + (1.0*z[6]) + (-1.0*z[7]) + (-1.0*z[8]));
 dm[6]=-(1.2)*((-2.0*d[2]) + (2.0*d[4]) + (1.0*d[5]) + (1.0*d[6]) + (-1.0*d[7]) + (-1.0*d[8]))+(1.-0.5*(1.2))*((-2.0*z[2]) + (2.0*z[4]) + (1.0*z[5]) + (1.0*z[6]) + (-1.0*z[7]) + (-1.0*z[8]));
 dm[7]=-(p.omega)*((1.0*d[1]) + (-1.0*d[2]) + (1.0*d[3]) + (-1.0*d[4]))+(1.-0.5*(p.omega))*((1.0*z[1]) + (-1.0*z[2]) + (1.0*z[3]) + (-1.0*z[4]));
 dm[8]=-(p.omega)*((1.0*d[5]) + (-1.0*d[6]) + (1.0*d[7]) + (-1.0*d[8]))+(1.-0.5*(p.omega))*((1.0*z[5]) + (-1.0*z[6]) + (1.0*z[7]) + (-1.0*z[8]));
 var post:array<f32,9>;
 post[0]=f[0]+(1.0/9.0*dm[0]) + (-4.0/36.0*dm[1]) + (4.0/36.0*dm[2]);
 post[1]=f[1]+(1.0/9.0*dm[0]) + (-1.0/36.0*dm[1]) + (-2.0/36.0*dm[2]) + (1.0/6.0*dm[3]) + (-2.0/12.0*dm[4]) + (1.0/4.0*dm[7]);
 post[2]=f[2]+(1.0/9.0*dm[0]) + (-1.0/36.0*dm[1]) + (-2.0/36.0*dm[2]) + (1.0/6.0*dm[5]) + (-2.0/12.0*dm[6]) + (-1.0/4.0*dm[7]);
 post[3]=f[3]+(1.0/9.0*dm[0]) + (-1.0/36.0*dm[1]) + (-2.0/36.0*dm[2]) + (-1.0/6.0*dm[3]) + (2.0/12.0*dm[4]) + (1.0/4.0*dm[7]);
 post[4]=f[4]+(1.0/9.0*dm[0]) + (-1.0/36.0*dm[1]) + (-2.0/36.0*dm[2]) + (-1.0/6.0*dm[5]) + (2.0/12.0*dm[6]) + (-1.0/4.0*dm[7]);
 post[5]=f[5]+(1.0/9.0*dm[0]) + (2.0/36.0*dm[1]) + (1.0/36.0*dm[2]) + (1.0/6.0*dm[3]) + (1.0/12.0*dm[4]) + (1.0/6.0*dm[5]) + (1.0/12.0*dm[6]) + (1.0/4.0*dm[8]);
 post[6]=f[6]+(1.0/9.0*dm[0]) + (2.0/36.0*dm[1]) + (1.0/36.0*dm[2]) + (-1.0/6.0*dm[3]) + (-1.0/12.0*dm[4]) + (1.0/6.0*dm[5]) + (1.0/12.0*dm[6]) + (-1.0/4.0*dm[8]);
 post[7]=f[7]+(1.0/9.0*dm[0]) + (2.0/36.0*dm[1]) + (1.0/36.0*dm[2]) + (-1.0/6.0*dm[3]) + (-1.0/12.0*dm[4]) + (-1.0/6.0*dm[5]) + (-1.0/12.0*dm[6]) + (1.0/4.0*dm[8]);
 post[8]=f[8]+(1.0/9.0*dm[0]) + (2.0/36.0*dm[1]) + (1.0/36.0*dm[2]) + (1.0/6.0*dm[3]) + (1.0/12.0*dm[4]) + (-1.0/6.0*dm[5]) + (-1.0/12.0*dm[6]) + (-1.0/4.0*dm[8]);

 for(var q=0u;q<9u;q++){
  let x=i32(i%p.nx)+C[q].x;let y=i32(i/p.nx)+C[q].y;
  if(x<0 || x>=i32(p.nx) || y<0 || y>=i32(p.ny)) { dst[OPP[q]*n+i]=post[q]; }
  else { let dest=u32(y)*p.nx+u32(x); if(mask[dest]!=0u){dst[OPP[q]*n+i]=post[q];} else {dst[q*n+dest]=post[q];} }
 }
}
@compute @workgroup_size(128)
fn macros(@builtin(global_invocation_id) id:vec3<u32>){
 let i=id.x;let n=p.nx*p.ny;if(i>=n){return;}
 var drho=0.;var j=vec2(0.);
 for(var q=0u;q<9u;q++){let f=src[q*n+i];drho+=f;j+=vec2<f32>(C[q])*f;}
 let rho=1.+drho;let u=(j+0.5*p.force)/rho*p.scale;
 output[i]=vec4(rho,u,drho);
}

@group(0) @binding(5) var<storage,read> boundary:array<vec4<f32>>;
fn fluid_velocity(i:u32)->vec2<f32>{
 let count=p.nx*p.ny;var drho=0.;var j=vec2(0.);
 for(var q=0u;q<9u;q++){let g=src[q*count+i];drho+=g;j+=vec2<f32>(C[q])*g;}
 return (j+0.5*p.force)/(1.+drho);
}
struct FitSample {index:u32,kind:u32,wn:f32,wt:f32}
@group(0) @binding(7) var<storage,read> fit:array<FitSample>;
fn lsq_gradient(i:u32)->vec4<f32>{
 let h=fit[i];let ub=boundary[i].yz;var dn=vec2(0.);var dt=vec2(0.);
 for(var k=0u;k<h.kind;k++){
  let sample=fit[h.index+k];var uj=vec2(0.);
  if(sample.kind==1u){uj=boundary[sample.index].yz;}else{uj=fluid_velocity(sample.index);}
  dn+=sample.wn*(uj-ub);dt+=sample.wt*(uj-ub);
 }
 return vec4(dn,dt);
}
@compute @workgroup_size(128)
fn reconstruct(@builtin(global_invocation_id) id:vec3<u32>) {
 let i=id.x;let count=p.nx*p.ny;if(i>=count || boundary[i].x==0.){return;}
 var n=vec2<i32>(1,0);
 switch u32(boundary[i].x){case 2u:{n=vec2(-1,0);}case 3u:{n=vec2(0,1);}case 4u:{n=vec2(0,-1);}default:{}}
 let t=vec2(-n.y,n.x);var a=0.;var b=0.;
 for(var q=0u;q<9u;q++){
  let cn=dot(C[q],n);let f=src[q*count+i]+W[q];
  if(cn==0){a+=f;}if(cn == -1){b+=f;}
 }
 let u=boundary[i].yz;let un=dot(u,vec2<f32>(n));
 let rho=(a+2.*b-0.5*dot(p.force,vec2<f32>(n)))/(1.-un);
 let g=lsq_gradient(i);let dx=f32(n.x)*g.xy+f32(t.x)*g.zw;let dy=f32(n.y)*g.xy+f32(t.y)*g.zw;
 let div=dx.x+dy.y;let dev=dx.x-dy.y;
 let pxx=-rho/3.*(div/1.1+dev/p.omega)-u.x*p.force.x;
 let pyy=-rho/3.*(div/1.1-dev/p.omega)-u.y*p.force.y;
 let pxy=-rho/(3.*p.omega)*(dy.x+dx.y)-0.5*(u.x*p.force.y+u.y*p.force.x);
 for(var q=0u;q<9u;q++){
  let cv=vec2<f32>(C[q]);let cu=dot(cv,u);
  let eq=W[q]*((rho-1.)+rho*(3.*cu+4.5*cu*cu-1.5*dot(u,u)));
  src[q*count+i]=eq+4.5*W[q]*((cv.x*cv.x-1./3.)*pxx+(cv.y*cv.y-1./3.)*pyy+2.*cv.x*cv.y*pxy)-1.5*W[q]*dot(cv,p.force);
 }
}

@group(0) @binding(6) var<storage,read> kicks:array<vec2<f32>>;
@compute @workgroup_size(128)
fn apply_kicks(@builtin(global_invocation_id) id:vec3<u32>) {
 let i=id.x; let n=p.nx*p.ny; if(i>=n || mask[i]!=0u){return;}
 for(var q=0u;q<9u;q++){src[q*n+i]+=3.*W[q]*dot(vec2<f32>(C[q]), kicks[i]);}
}

@group(0) @binding(8) var<uniform> density_control:vec4<f32>;
@compute @workgroup_size(128)
fn remove_mean_offset(@builtin(global_invocation_id) id:vec3<u32>){
 let i=id.x;let n=p.nx*p.ny;if(i>=n || mask[i]!=0u){return;}
 var drho=0.;var j=vec2(0.);
 for(var q=0u;q<9u;q++){let g=src[q*n+i];drho+=g;j+=vec2<f32>(C[q])*g;}
 let rho=1.+drho;let u=(j+0.5*p.force)/rho;
 for(var q=0u;q<9u;q++){
  let cu=dot(vec2<f32>(C[q]),u);
  src[q*n+i]-=density_control.x*W[q]*(1.+3.*cu+4.5*cu*cu-1.5*dot(u,u));
 }
}
