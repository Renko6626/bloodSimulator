// D2Q9 shifted populations g=f-w. Orthogonal raw-moment MRT, Guo force.
struct Params { nx:u32, ny:u32, periodic_y:u32, omega:f32, force:vec2<f32>, scale:f32, pad:f32 }
@group(0) @binding(0) var<uniform> p:Params;
@group(0) @binding(1) var<storage,read_write> src:array<f32>;
@group(0) @binding(2) var<storage,read_write> dst:array<f32>;
@group(0) @binding(3) var<storage,read_write> output:array<vec4<f32>>;
@group(0) @binding(4) var<storage,read> kicks:array<vec2<f32>>;
const C=array<vec2<i32>,9>(vec2(0,0),vec2(1,0),vec2(0,1),vec2(-1,0),vec2(0,-1),vec2(1,1),vec2(-1,1),vec2(-1,-1),vec2(1,-1));
const W=array<f32,9>(4./9.,1./9.,1./9.,1./9.,1./9.,1./36.,1./36.,1./36.,1./36.);
const OPP=array<u32,9>(0,3,4,1,2,7,8,5,6);
@compute @workgroup_size(128)
fn collide_stream(@builtin(global_invocation_id) id:vec3<u32>) {
 let i=id.x;let n=p.nx*p.ny;if(i>=n){return;}
 var f:array<f32,9>;var drho=0.;var j=vec2(0.);
 for(var q=0u;q<9u;q++){f[q]=src[q*n+i];drho+=f[q];j+=vec2<f32>(C[q])*f[q];}
 let rho=1.+drho;let u=(j+0.5*p.force)/rho;
 var d:array<f32,9>;var z:array<f32,9>;
 for(var q=0u;q<9u;q++){
  let cv=vec2<f32>(C[q]);let cu=dot(cv,u);
  let eq=W[q]*(drho+rho*(3.*cu+4.5*cu*cu-1.5*dot(u,u)));
  d[q]=f[q]-eq;z[q]=W[q]*dot(3.*(cv-u)+9.*cu*cv,p.force);
 }
 var dm:array<f32,9>;
 dm[0]=-(0.)*((1.0*d[0]) + (1.0*d[1]) + (1.0*d[2]) + (1.0*d[3]) + (1.0*d[4]) + (1.0*d[5]) + (1.0*d[6]) + (1.0*d[7]) + (1.0*d[8]))+(1.-0.5*(0.))*((1.0*z[0]) + (1.0*z[1]) + (1.0*z[2]) + (1.0*z[3]) + (1.0*z[4]) + (1.0*z[5]) + (1.0*z[6]) + (1.0*z[7]) + (1.0*z[8]));
 dm[1]=-(1.1)*((-4.0*d[0]) + (-1.0*d[1]) + (-1.0*d[2]) + (-1.0*d[3]) + (-1.0*d[4]) + (2.0*d[5]) + (2.0*d[6]) + (2.0*d[7]) + (2.0*d[8]))+(1.-0.5*(1.1))*((-4.0*z[0]) + (-1.0*z[1]) + (-1.0*z[2]) + (-1.0*z[3]) + (-1.0*z[4]) + (2.0*z[5]) + (2.0*z[6]) + (2.0*z[7]) + (2.0*z[8]));
 dm[2]=-(1.)*((4.0*d[0]) + (-2.0*d[1]) + (-2.0*d[2]) + (-2.0*d[3]) + (-2.0*d[4]) + (1.0*d[5]) + (1.0*d[6]) + (1.0*d[7]) + (1.0*d[8]))+(1.-0.5*(1.))*((4.0*z[0]) + (-2.0*z[1]) + (-2.0*z[2]) + (-2.0*z[3]) + (-2.0*z[4]) + (1.0*z[5]) + (1.0*z[6]) + (1.0*z[7]) + (1.0*z[8]));
 dm[3]=-(0.)*((1.0*d[1]) + (-1.0*d[3]) + (1.0*d[5]) + (-1.0*d[6]) + (-1.0*d[7]) + (1.0*d[8]))+(1.-0.5*(0.))*((1.0*z[1]) + (-1.0*z[3]) + (1.0*z[5]) + (-1.0*z[6]) + (-1.0*z[7]) + (1.0*z[8]));
 dm[4]=-(1.2)*((-2.0*d[1]) + (2.0*d[3]) + (1.0*d[5]) + (-1.0*d[6]) + (-1.0*d[7]) + (1.0*d[8]))+(1.-0.5*(1.2))*((-2.0*z[1]) + (2.0*z[3]) + (1.0*z[5]) + (-1.0*z[6]) + (-1.0*z[7]) + (1.0*z[8]));
 dm[5]=-(0.)*((1.0*d[2]) + (-1.0*d[4]) + (1.0*d[5]) + (1.0*d[6]) + (-1.0*d[7]) + (-1.0*d[8]))+(1.-0.5*(0.))*((1.0*z[2]) + (-1.0*z[4]) + (1.0*z[5]) + (1.0*z[6]) + (-1.0*z[7]) + (-1.0*z[8]));
 dm[6]=-(1.2)*((-2.0*d[2]) + (2.0*d[4]) + (1.0*d[5]) + (1.0*d[6]) + (-1.0*d[7]) + (-1.0*d[8]))+(1.-0.5*(1.2))*((-2.0*z[2]) + (2.0*z[4]) + (1.0*z[5]) + (1.0*z[6]) + (-1.0*z[7]) + (-1.0*z[8]));
 dm[7]=-(p.omega)*((1.0*d[1]) + (-1.0*d[2]) + (1.0*d[3]) + (-1.0*d[4]))+(1.-0.5*(p.omega))*((1.0*z[1]) + (-1.0*z[2]) + (1.0*z[3]) + (-1.0*z[4]));
 dm[8]=-(p.omega)*((1.0*d[5]) + (-1.0*d[6]) + (1.0*d[7]) + (-1.0*d[8]))+(1.-0.5*(p.omega))*((1.0*z[5]) + (-1.0*z[6]) + (1.0*z[7]) + (-1.0*z[8]));
 var post:array<f32,9>;
 post[0]=f[0]+(1.0/9.0*dm[0]) + (-4.0/36.0*dm[1]) + (4.0/36.0*dm[2]);
 post[1]=f[1]+(1.0/9.0*dm[0]) + (-1.0/36.0*dm[1]) + (-2.0/36.0*dm[2]) + (1.0/6.0*dm[3]) + (-2.0/12.0*dm[4]) + (1.0/4.0*dm[7]);
 post[2]=f[2]+(1.0/9.0*dm[0]) + (-1.0/36.0*dm[1]) + (-2.0/36.0*dm[2]) + (1.0/6.0*dm[5]) + (-2.0/12.0*dm[6]) + (-1.0/4.0*dm[7]);
 post[3]=f[3]+(1.0/9.0*dm[0]) + (-1.0/36.0*dm[1]) + (-2.0/36.0*dm[2]) + (-1.0/6.0*dm[3]) + (2.0/12.0*dm[4]) + (1.0/4.0*dm[7]);
 post[4]=f[4]+(1.0/9.0*dm[0]) + (-1.0/36.0*dm[1]) + (-2.0/36.0*dm[2]) + (-1.0/6.0*dm[5]) + (2.0/12.0*dm[6]) + (-1.0/4.0*dm[7]);
 post[5]=f[5]+(1.0/9.0*dm[0]) + (2.0/36.0*dm[1]) + (1.0/36.0*dm[2]) + (1.0/6.0*dm[3]) + (1.0/12.0*dm[4]) + (1.0/6.0*dm[5]) + (1.0/12.0*dm[6]) + (1.0/4.0*dm[8]);
 post[6]=f[6]+(1.0/9.0*dm[0]) + (2.0/36.0*dm[1]) + (1.0/36.0*dm[2]) + (-1.0/6.0*dm[3]) + (-1.0/12.0*dm[4]) + (1.0/6.0*dm[5]) + (1.0/12.0*dm[6]) + (-1.0/4.0*dm[8]);
 post[7]=f[7]+(1.0/9.0*dm[0]) + (2.0/36.0*dm[1]) + (1.0/36.0*dm[2]) + (-1.0/6.0*dm[3]) + (-1.0/12.0*dm[4]) + (-1.0/6.0*dm[5]) + (-1.0/12.0*dm[6]) + (1.0/4.0*dm[8]);
 post[8]=f[8]+(1.0/9.0*dm[0]) + (2.0/36.0*dm[1]) + (1.0/36.0*dm[2]) + (1.0/6.0*dm[3]) + (1.0/12.0*dm[4]) + (-1.0/6.0*dm[5]) + (-1.0/12.0*dm[6]) + (-1.0/4.0*dm[8]);

 for(var q=0u;q<9u;q++){
  let x=i32(i%p.nx)+C[q].x;let y=i32(i/p.nx)+C[q].y;
  if(p.periodic_y==0u && (y<0 || y>=i32(p.ny))){dst[OPP[q]*n+i]=post[q];}
  else{let xx=u32((x+i32(p.nx))%i32(p.nx));let yy=u32((y+i32(p.ny))%i32(p.ny));dst[q*n+yy*p.nx+xx]=post[q];}
 }
}
@compute @workgroup_size(128)
fn kick(@builtin(global_invocation_id) id:vec3<u32>){
 let i=id.x;let n=p.nx*p.ny;if(i>=n){return;}
 for(var q=0u;q<9u;q++){src[q*n+i]+=3.*W[q]*dot(vec2<f32>(C[q]),kicks[i]);}
}
@compute @workgroup_size(128)
fn macros(@builtin(global_invocation_id) id:vec3<u32>){
 let i=id.x;let n=p.nx*p.ny;if(i>=n){return;}
 var drho=0.;var j=vec2(0.);
 for(var q=0u;q<9u;q++){let f=src[q*n+i];drho+=f;j+=vec2<f32>(C[q])*f;}
 let rho=1.+drho;let u=(j+0.5*p.force)/rho*p.scale;
 output[i]=vec4(rho,u,drho);
}
